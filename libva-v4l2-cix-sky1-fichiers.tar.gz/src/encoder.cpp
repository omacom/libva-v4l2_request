// SPDX-License-Identifier: MIT
#include "internal.hpp"
#include <linux/videodev2.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <glob.h>
#include <poll.h>
#include <cerrno>
#include <limits>
#include <array>

namespace irisva {
namespace {
constexpr unsigned OUTPUT = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
constexpr unsigned CAPTURE = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
int call(int fd, unsigned long command, void *arg) {
    int ret;
    do {
        ret = ioctl(fd, command, arg);
    } while (ret < 0 && errno == EINTR);
    return ret;
}
void checked(int fd, unsigned long command, void *arg, const char *name) {
    if (call(fd, command, arg) < 0)
        throw Error(VA_STATUS_ERROR_ENCODING_ERROR, std::string(name) + ": " + strerror(errno));
}
// The plane count must match the queue: Linlon describes NV12 input as two
// discrete planes, Iris as one. Coded CAPTURE buffers always have one plane.
struct QueueBuffer {
    v4l2_plane planes[VIDEO_MAX_PLANES]{};
    v4l2_plane &plane = planes[0];
    v4l2_buffer buffer{};
    explicit QueueBuffer(unsigned type, unsigned index = 0, bool import = false,
                         unsigned count = 1) {
        buffer.type = type;
        buffer.index = index;
        buffer.memory = type == OUTPUT && import ? V4L2_MEMORY_DMABUF : V4L2_MEMORY_MMAP;
        buffer.length = count;
        buffer.m.planes = planes;
    }
    QueueBuffer(const QueueBuffer &) = delete;
    QueueBuffer &operator=(const QueueBuffer &) = delete;
};
bool parameter_set(unsigned type, bool hevc) {
    return hevc ? type == 32 || type == 33 || type == 34 : type == 7 || type == 8;
}
bool vcl(unsigned type, bool hevc) {
    return hevc ? type < 32 : type >= 1 && type <= 5;
}
bool random_access(unsigned type, bool hevc) {
    return hevc ? type >= 16 && type <= 21 : type == 5;
}
// Annex B prefix of a coded buffer, scanned only up to its first slice:
// parameter sets always precede the VCL NAL units they apply to.
struct NalPrefix {
    bool parameters = false, slice = false, random_access = false;
    size_t first_slice = 0; // Start-code offset of the first VCL NAL unit.
};
NalPrefix scan_prefix(const uint8_t *data, size_t size, bool hevc) {
    NalPrefix result;
    result.first_slice = size;
    for (size_t i = 0; i + 3 < size; ++i) {
        if (data[i] || data[i + 1] || data[i + 2] != 1)
            continue;
        const unsigned type = hevc ? (data[i + 3] >> 1) & 63 : data[i + 3] & 31;
        result.parameters |= parameter_set(type, hevc);
        if (vcl(type, hevc)) {
            result.slice = true;
            result.random_access = random_access(type, hevc);
            result.first_slice = i && !data[i - 1] ? i - 1 : i;
            break;
        }
        i += 2;
    }
    return result;
}
template <class T> T parameter(const Buffer &b, size_t offset = 0) {
    check(b.elements == 1 && b.data.size() >= offset + sizeof(T), "short encode parameter buffer",
          VA_STATUS_ERROR_INVALID_BUFFER);
    T value;
    std::memcpy(&value, b.data.data() + offset, sizeof(value));
    return value;
}
int level_control(unsigned idc) {
    const unsigned levels[] = {10, 9,  11, 12, 13, 20, 21, 22, 30,
                               31, 32, 40, 41, 42, 50, 51, 52, 60};
    for (unsigned i = 0; i < std::size(levels); ++i)
        if (levels[i] == idc)
            return i;
    throw Error(VA_STATUS_ERROR_INVALID_PARAMETER, "unsupported H264 encode level");
}
int hevc_level_control(unsigned idc) {
    const unsigned levels[] = {30, 60, 63, 90, 93, 120, 123, 150, 153, 156, 180, 183, 186};
    for (unsigned i = 0; i < std::size(levels); ++i)
        if (levels[i] == idc)
            return i;
    throw Error(VA_STATUS_ERROR_INVALID_PARAMETER, "unsupported HEVC encode level");
}
std::array<int, 3> deblocking(const EncodePicture &p, bool hevc) {
    if (hevc) {
        const auto &slice = p.hevc_slices.front();
        bool disabled = slice.slice_fields.bits.slice_deblocking_filter_disabled_flag;
        int mode = slice.slice_fields.bits.slice_loop_filter_across_slices_enabled_flag ? 0 : 2;
        return {disabled ? 1 : mode, disabled ? 0 : slice.slice_beta_offset_div2,
                disabled ? 0 : slice.slice_tc_offset_div2};
    }
    const auto &slice = p.slices.front();
    // Offsets are absent from the slice header when filtering is disabled.
    return {slice.disable_deblocking_filter_idc,
            slice.disable_deblocking_filter_idc == 1 ? 0 : slice.slice_alpha_c0_offset_div2,
            slice.disable_deblocking_filter_idc == 1 ? 0 : slice.slice_beta_offset_div2};
}
void validate_h264(const EncodeSettings &s, const EncodePicture &p, unsigned width,
                   unsigned height) {
    check(s.has_sequence && p.has_params && p.slices.size() == 1,
          "encoding requires a sequence, picture and one slice", VA_STATUS_ERROR_INVALID_PARAMETER);
    const auto &seq = s.sequence;
    const auto &pic = p.params;
    const auto &slice = p.slices.front();
    check(!pic.pic_fields.bits.idr_pic_flag || slice.slice_type % 5 == 2, "IDR requires an I slice",
          VA_STATUS_ERROR_UNIMPLEMENTED);
    check(seq.picture_width_in_mbs == (width + 15) / 16 &&
              seq.picture_height_in_mbs == (height + 15) / 16,
          "encode sequence dimensions do not match context", VA_STATUS_ERROR_INVALID_PARAMETER);
    check(seq.seq_fields.bits.frame_mbs_only_flag && seq.seq_fields.bits.chroma_format_idc == 1 &&
              !seq.bit_depth_luma_minus8 && !seq.bit_depth_chroma_minus8 &&
              !seq.seq_fields.bits.seq_scaling_matrix_present_flag && seq.ip_period <= 1 &&
              seq.max_num_ref_frames <= 1,
          "only progressive 8-bit H264 I/P encoding is supported", VA_STATUS_ERROR_UNIMPLEMENTED);
    check(slice.macroblock_address == 0 &&
              slice.num_macroblocks ==
                  unsigned(seq.picture_width_in_mbs) * seq.picture_height_in_mbs &&
              (slice.slice_type % 5 == 0 || slice.slice_type % 5 == 2),
          "only one full-picture I or P slice is supported", VA_STATUS_ERROR_UNIMPLEMENTED);
    check(!pic.pic_fields.bits.weighted_pred_flag && !pic.pic_fields.bits.weighted_bipred_idc &&
              !pic.pic_fields.bits.pic_scaling_matrix_present_flag && !pic.chroma_qp_index_offset &&
              !pic.second_chroma_qp_index_offset && !pic.num_ref_idx_l0_active_minus1 &&
              !slice.num_ref_idx_l0_active_minus1 && !slice.cabac_init_idc,
          "unsupported H264 encode picture features", VA_STATUS_ERROR_UNIMPLEMENTED);
    const auto filter = deblocking(p, false);
    check(filter[0] <= 2 && filter[1] >= -6 && filter[1] <= 6 && filter[2] >= -6 && filter[2] <= 6,
          "invalid H264 encode deblocking request", VA_STATUS_ERROR_INVALID_PARAMETER);
    check(!seq.frame_crop_left_offset && !seq.frame_crop_top_offset &&
              (!seq.frame_cropping_flag ||
               (uint64_t(width) + uint64_t(seq.frame_crop_right_offset) * 2 ==
                    unsigned(seq.picture_width_in_mbs) * 16 &&
                uint64_t(height) + uint64_t(seq.frame_crop_bottom_offset) * 2 ==
                    unsigned(seq.picture_height_in_mbs) * 16)),
          "unsupported encode cropping", VA_STATUS_ERROR_INVALID_PARAMETER);
}
void validate_hevc(const EncodeSettings &s, const EncodePicture &p, unsigned width,
                   unsigned height) {
    check(s.has_sequence && p.has_params && p.hevc_slices.size() == 1,
          "encoding requires a sequence, picture and one slice", VA_STATUS_ERROR_INVALID_PARAMETER);
    const auto &seq = s.hevc_sequence;
    const auto &pic = p.hevc_params;
    const auto &slice = p.hevc_slices.front();
    check(seq.general_profile_idc == 1 && seq.seq_fields.bits.chroma_format_idc == 1 &&
              !seq.seq_fields.bits.bit_depth_luma_minus8 &&
              !seq.seq_fields.bits.bit_depth_chroma_minus8 &&
              !seq.seq_fields.bits.separate_colour_plane_flag &&
              !seq.seq_fields.bits.pcm_enabled_flag && !seq.seq_fields.bits.hierachical_flag &&
              !seq.vui_fields.bits.field_seq_flag && seq.ip_period <= 1,
          "only progressive 8-bit HEVC Main I/P encoding is supported",
          VA_STATUS_ERROR_UNIMPLEMENTED);
    check(seq.log2_min_luma_coding_block_size_minus3 <= 3 &&
              seq.log2_diff_max_min_luma_coding_block_size <= 3 &&
              seq.log2_min_luma_coding_block_size_minus3 +
                      seq.log2_diff_max_min_luma_coding_block_size <=
                  3,
          "invalid HEVC coding block sizes", VA_STATUS_ERROR_INVALID_PARAMETER);
    trace("HEVC sequence=%ux%u visible=%ux%u min-cb-log2=%u ctu-diff=%u",
          seq.pic_width_in_luma_samples, seq.pic_height_in_luma_samples, width, height,
          seq.log2_min_luma_coding_block_size_minus3 + 3,
          seq.log2_diff_max_min_luma_coding_block_size);
    unsigned min_cb = 1u << (seq.log2_min_luma_coding_block_size_minus3 + 3);
    unsigned ctu = min_cb << seq.log2_diff_max_min_luma_coding_block_size;
    // HEVC VA sequence parameters lack a conformance window. The input surface
    // and context supply visible dimensions; the sequence may include CU padding.
    // Older FFmpeg clients align to 16 even when their SPS declares 8-pixel CUs.
    check(seq.pic_width_in_luma_samples >= width &&
              seq.pic_width_in_luma_samples - width < std::max(16u, min_cb) &&
              seq.pic_height_in_luma_samples >= height &&
              seq.pic_height_in_luma_samples - height < std::max(16u, min_cb),
          "HEVC sequence dimensions do not match input", VA_STATUS_ERROR_INVALID_PARAMETER);
    check(slice.slice_segment_address == 0 &&
              slice.num_ctu_in_slice == ((seq.pic_width_in_luma_samples + ctu - 1) / ctu) *
                                            ((seq.pic_height_in_luma_samples + ctu - 1) / ctu) &&
              (slice.slice_type == 1 || slice.slice_type == 2) &&
              (!pic.pic_fields.bits.idr_pic_flag || slice.slice_type == 2) &&
              pic.pic_fields.bits.coding_type == (slice.slice_type == 2 ? 1u : 2u),
          "only one full-picture HEVC I or P slice is supported", VA_STATUS_ERROR_UNIMPLEMENTED);
    check(!pic.pic_fields.bits.tiles_enabled_flag && !pic.num_tile_columns_minus1 &&
              !pic.num_tile_rows_minus1 && !pic.pic_fields.bits.entropy_coding_sync_enabled_flag &&
              !pic.pic_fields.bits.dependent_slice_segments_enabled_flag &&
              !pic.pic_fields.bits.weighted_pred_flag &&
              !pic.pic_fields.bits.weighted_bipred_flag &&
              !pic.pic_fields.bits.transquant_bypass_enabled_flag &&
              !pic.pic_fields.bits.scaling_list_data_present_flag &&
              !pic.num_ref_idx_l0_default_active_minus1 && !slice.num_ref_idx_l0_active_minus1 &&
              !pic.pps_cb_qp_offset && !pic.pps_cr_qp_offset && !slice.slice_cb_qp_offset &&
              !slice.slice_cr_qp_offset && !slice.slice_fields.bits.dependent_slice_segment_flag &&
              !slice.slice_fields.bits.colour_plane_id && !pic.ctu_max_bitsize_allowed,
          "unsupported HEVC encode picture features", VA_STATUS_ERROR_UNIMPLEMENTED);
    check(slice.slice_fields.bits.slice_deblocking_filter_disabled_flag <= 1 &&
              slice.slice_beta_offset_div2 >= -6 && slice.slice_beta_offset_div2 <= 6 &&
              slice.slice_tc_offset_div2 >= -6 && slice.slice_tc_offset_div2 <= 6 &&
              seq.general_tier_flag <= 1 &&
              (!seq.general_tier_flag || seq.general_level_idc >= 120),
          "invalid HEVC filter or tier", VA_STATUS_ERROR_INVALID_PARAMETER);
}
void validate(const EncodeSettings &s, const EncodePicture &p, unsigned width, unsigned height) {
    if (s.hevc)
        validate_hevc(s, p, width, height);
    else
        validate_h264(s, p, width, height);
    check(s.fps_num && s.fps_den && s.fps_num >= s.fps_den &&
              uint64_t(s.fps_num) <= uint64_t(s.fps_den) * 240,
          "unsupported encode frame rate", VA_STATUS_ERROR_INVALID_PARAMETER);
    check(s.min_qp >= 1 && s.max_qp <= 51 && s.min_qp <= s.max_qp, "invalid encode QP limits",
          VA_STATUS_ERROR_INVALID_PARAMETER);
    if (s.rate_control != VA_RC_CQP)
        check(s.bitrate && s.bitrate <= s.peak_bitrate && s.peak_bitrate <= 245000000,
              "invalid encode bitrate", VA_STATUS_ERROR_INVALID_PARAMETER);
}
} // namespace

std::string find_encoder_device() {
    static const char *const environment[] = {"LIBVA_V4L2_ENCODER_DEVICE",
                                              "IRIS_VAAPI_ENCODER_DEVICE", nullptr};
    return find_codec_device(true, environment);
}

void render_encode_buffer(EncodeSettings &s, EncodePicture &p, const Buffer &b) {
    switch (b.type) {
    case VAEncSequenceParameterBufferType:
        if (s.hevc) {
            s.hevc_sequence = parameter<VAEncSequenceParameterBufferHEVC>(b);
            s.has_sequence = true;
            const auto &seq = s.hevc_sequence;
            if (seq.vui_parameters_present_flag &&
                seq.vui_fields.bits.vui_timing_info_present_flag) {
                s.fps_num = seq.vui_time_scale;
                s.fps_den = seq.vui_num_units_in_tick;
            }
            if (!s.bitrate)
                s.bitrate = s.peak_bitrate = seq.bits_per_second;
            break;
        }
        s.sequence = parameter<VAEncSequenceParameterBufferH264>(b);
        s.has_sequence = true;
        if (s.sequence.vui_parameters_present_flag &&
            s.sequence.vui_fields.bits.timing_info_present_flag) {
            check(s.sequence.num_units_in_tick <= std::numeric_limits<unsigned>::max() / 2,
                  "invalid encoder timing", VA_STATUS_ERROR_INVALID_PARAMETER);
            s.fps_num = s.sequence.time_scale;
            s.fps_den = s.sequence.num_units_in_tick * 2;
        }
        if (!s.bitrate)
            s.bitrate = s.peak_bitrate = s.sequence.bits_per_second;
        break;
    case VAEncPictureParameterBufferType:
        if (s.hevc)
            p.hevc_params = parameter<VAEncPictureParameterBufferHEVC>(b);
        else
            p.params = parameter<VAEncPictureParameterBufferH264>(b);
        p.has_params = true;
        break;
    case VAEncSliceParameterBufferType:
        if (s.hevc) {
            check(b.element_size >= sizeof(VAEncSliceParameterBufferHEVC),
                  "short HEVC encode slice", VA_STATUS_ERROR_INVALID_BUFFER);
            for (unsigned i = 0; i < b.elements; ++i) {
                VAEncSliceParameterBufferHEVC slice;
                std::memcpy(&slice, b.data.data() + size_t(i) * b.element_size, sizeof(slice));
                p.hevc_slices.push_back(slice);
            }
            break;
        }
        check(b.element_size >= sizeof(VAEncSliceParameterBufferH264), "short encode slice",
              VA_STATUS_ERROR_INVALID_BUFFER);
        for (unsigned i = 0; i < b.elements; ++i) {
            VAEncSliceParameterBufferH264 slice;
            std::memcpy(&slice, b.data.data() + size_t(i) * b.element_size, sizeof(slice));
            p.slices.push_back(slice);
        }
        break;
    case VAEncMiscParameterBufferType: {
        auto misc = parameter<VAEncMiscParameterBuffer>(b);
        const size_t off = offsetof(VAEncMiscParameterBuffer, data);
        switch (misc.type) {
        case VAEncMiscParameterTypeRateControl: {
            auto rc = parameter<VAEncMiscParameterRateControl>(b, off);
            check(!rc.rc_flags.bits.temporal_id && !rc.rc_flags.bits.reset &&
                      !rc.rc_flags.bits.enable_parallel_brc &&
                      !rc.rc_flags.bits.enable_dynamic_scaling && !rc.target_frame_size,
                  "unsupported encode rate control feature", VA_STATUS_ERROR_UNIMPLEMENTED);
            check(rc.target_percentage <= 100, "invalid target bitrate percentage",
                  VA_STATUS_ERROR_INVALID_PARAMETER);
            s.peak_bitrate = rc.bits_per_second;
            s.bitrate = s.rate_control == VA_RC_VBR && rc.target_percentage
                            ? uint64_t(rc.bits_per_second) * rc.target_percentage / 100
                            : rc.bits_per_second;
            s.min_qp = rc.min_qp ? rc.min_qp : 1;
            s.max_qp = rc.max_qp ? rc.max_qp : 51;
            break;
        }
        case VAEncMiscParameterTypeFrameRate: {
            auto fr = parameter<VAEncMiscParameterFrameRate>(b, off);
            check(!fr.framerate_flags.bits.temporal_id, "temporal layers unsupported",
                  VA_STATUS_ERROR_UNIMPLEMENTED);
            s.fps_num = fr.framerate & 0xffff;
            s.fps_den = std::max(1u, fr.framerate >> 16);
            break;
        }
        case VAEncMiscParameterTypeQualityLevel: {
            auto quality = parameter<VAEncMiscParameterBufferQualityLevel>(b, off);
            check(quality.quality_level <= 1, "unsupported encoder quality level",
                  VA_STATUS_ERROR_INVALID_PARAMETER);
            break;
        }
        case VAEncMiscParameterTypeHRD:
            // Iris has no CPB size/fullness control. The firmware owns the
            // rate-control buffer; HRD values are advisory for this backend.
            (void)parameter<VAEncMiscParameterHRD>(b, off);
            break;
        default:
            throw Error(VA_STATUS_ERROR_UNIMPLEMENTED, "unsupported encode misc parameter");
        }
        break;
    }
    default:
        throw Error(VA_STATUS_ERROR_UNSUPPORTED_BUFFERTYPE, "unsupported encode buffer");
    }
}

struct Encoder::Impl {
    int fd = -1, render_fd = -1;
    bool import = false;
    CodecDriver driver = CodecDriver::Unknown;
    // Linlon has no PREPEND_SPSPPS_TO_IDR / HEADER_MODE controls. Its
    // firmware emits parameter sets once, as a separate CAPTURE buffer.
    bool emulate_prepend = false;
    std::vector<uint8_t> pending_header, cached_header;
    unsigned input_planes = 1;
    unsigned plane_sizes[2] = {};
    struct Job {
        std::shared_ptr<EncodeTask> task;
        std::shared_ptr<Buffer> output;
        std::shared_ptr<Memory> memory;
        bool input_done = false, frame_done = false;
    };
    std::vector<std::shared_ptr<Memory>> staging;
    std::vector<std::shared_ptr<Job>> slots;
    std::map<uint64_t, std::shared_ptr<Job>> jobs;
    int current_qp = -1;
    std::unique_ptr<SurfaceCopier> copier;
    unsigned width, height, stride = 0, storage_height = 0, input_size = 0, input_count = 0;
    bool output_on = false, capture_on = false, failed = false;
    uint64_t token = 0;
    VASurfaceID last_reference = VA_INVALID_SURFACE;
    EncodeSettings settings;
    unsigned entropy;
    std::array<int, 3> filter{};
    std::vector<std::shared_ptr<Memory>> capture, raw;

    Impl(unsigned w, unsigned h, const EncodeSettings &s, unsigned cabac)
        : width(w), height(h), settings(s), entropy(cabac) {}
    ~Impl() {
        stop(VA_STATUS_ERROR_INVALID_CONTEXT);
        if (fd >= 0)
            close(fd);
        copier.reset();
        if (render_fd >= 0)
            close(render_fd);
    }
    void control(unsigned id, int value) {
        v4l2_control ctrl{};
        ctrl.id = id;
        ctrl.value = value;
        trace("encoder control id=%#x value=%d", id, value);
        checked(fd, VIDIOC_S_CTRL, &ctrl, "encoder S_CTRL");
    }
    // Returns false if the driver does not implement the control at all.
    bool optional_control(unsigned id, int value) {
        v4l2_queryctrl query{};
        query.id = id;
        if (call(fd, VIDIOC_QUERYCTRL, &query) < 0 || (query.flags & V4L2_CTRL_FLAG_DISABLED)) {
            trace("encoder control id=%#x unsupported by driver", id);
            return false;
        }
        control(id, value);
        return true;
    }
    void configure_deblocking() {
        const int ids[] = {settings.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_LOOP_FILTER_MODE
                                         : V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_MODE,
                           settings.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_LF_BETA_OFFSET_DIV2
                                         : V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_ALPHA,
                           settings.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_LF_TC_OFFSET_DIV2
                                         : V4L2_CID_MPEG_VIDEO_H264_LOOP_FILTER_BETA};
        bool supported = true;
        for (auto id : ids) {
            v4l2_queryctrl query{};
            query.id = id;
            if (call(fd, VIDIOC_QUERYCTRL, &query) < 0) {
                check(errno == EINVAL, "query encoder deblocking controls",
                      VA_STATUS_ERROR_ENCODING_ERROR);
                supported = false;
            } else if (query.flags & V4L2_CTRL_FLAG_DISABLED) {
                supported = false;
            }
        }
        if (!supported) {
            // Older Iris kernels only expose firmware's enabled, 0/0 default.
            // Never silently replace a non-default request with that default.
            check((filter[0] == 0 || (settings.hevc && filter[0] == 2)) && !filter[1] && !filter[2],
                  "deblocking request requires V4L2 loop-filter controls",
                  VA_STATUS_ERROR_UNIMPLEMENTED);
            return;
        }
        // Firmware can override slice offsets: on the tested SC8280XP, CQP
        // retains 0/0 and CBR/VBR can adjust them per frame. Forward the request
        // without rewriting headers that describe the firmware's actual filtering.
        const int modes[] = {V4L2_MPEG_VIDEO_H264_LOOP_FILTER_MODE_ENABLED,
                             V4L2_MPEG_VIDEO_H264_LOOP_FILTER_MODE_DISABLED,
                             V4L2_MPEG_VIDEO_H264_LOOP_FILTER_MODE_DISABLED_AT_SLICE_BOUNDARY};
        const int hevc_modes[] = {V4L2_MPEG_VIDEO_HEVC_LOOP_FILTER_MODE_ENABLED,
                                  V4L2_MPEG_VIDEO_HEVC_LOOP_FILTER_MODE_DISABLED,
                                  V4L2_MPEG_VIDEO_HEVC_LOOP_FILTER_MODE_DISABLED_AT_SLICE_BOUNDARY};
        control(ids[0], settings.hevc ? hevc_modes[filter[0]] : modes[filter[0]]);
        control(ids[1], filter[1]);
        control(ids[2], filter[2]);
        trace("encoder deblocking mode=%d alpha=%d beta=%d via V4L2", filter[0], filter[1],
              filter[2]);
    }
    void queue_capture(unsigned index) {
        QueueBuffer q(CAPTURE, index);
        q.plane.length = capture[index]->size;
        checked(fd, VIDIOC_QBUF, &q.buffer, "encoder QBUF CAPTURE");
    }
    // Moves one coded picture into its VA buffer, adding parameter sets the
    // firmware delivered separately or, for Linlon, only once per stream.
    void deliver(Buffer &output, const uint8_t *data, unsigned size, const NalPrefix &nal) {
        const std::vector<uint8_t> *prefix = nullptr;
        if (!pending_header.empty())
            prefix = &pending_header;
        else if (emulate_prepend && nal.random_access && !nal.parameters && !cached_header.empty())
            prefix = &cached_header;
        const size_t total = size + (prefix ? prefix->size() : 0);
        if (total > output.data.size()) {
            output.coded.status = VA_CODED_BUF_STATUS_SLICE_OVERFLOW_MASK;
            throw Error(VA_STATUS_ERROR_NOT_ENOUGH_BUFFER, "coded buffer too small");
        }
        size_t offset = 0;
        if (prefix) {
            std::memcpy(output.data.data(), prefix->data(), prefix->size());
            offset = prefix->size();
        }
        std::memcpy(output.data.data() + offset, data, size);
        // Remember in-band parameter sets for later forced keyframes.
        if (nal.parameters)
            cached_header.assign(data, data + nal.first_slice);
        pending_header.clear();
        output.coded.size = unsigned(total);
        output.coded.buf = output.data.data();
    }
    void stop(VAStatus status) noexcept {
        if (fd >= 0) {
            unsigned type = OUTPUT;
            if (output_on)
                call(fd, VIDIOC_STREAMOFF, &type);
            output_on = false;
            type = CAPTURE;
            if (capture_on)
                call(fd, VIDIOC_STREAMOFF, &type);
            capture_on = false;
        }
        failed = true;
        // STREAMOFF must precede release of imported input storage.
        for (auto &[token, job] : jobs) {
            job->task->status = status;
            job->task->pending = false;
            job->output->coded_ready = false;
        }
        jobs.clear();
        for (auto &slot : slots)
            slot.reset();
    }
    void refresh() {
        if (jobs.empty())
            return;
        try {
            for (;;) {
                QueueBuffer q(OUTPUT, 0, import, input_planes);
                if (call(fd, VIDIOC_DQBUF, &q.buffer) < 0) {
                    check(errno == EAGAIN, "encoder DQBUF OUTPUT failed",
                          VA_STATUS_ERROR_ENCODING_ERROR);
                    break;
                }
                check(q.buffer.index < slots.size() && slots[q.buffer.index] &&
                          !slots[q.buffer.index]->input_done &&
                          !(q.buffer.flags & V4L2_BUF_FLAG_ERROR),
                      "invalid encoder input completion", VA_STATUS_ERROR_ENCODING_ERROR);
                slots[q.buffer.index]->input_done = true;
                // OUTPUT DQBUF returns ownership of the raw slot even if the
                // corresponding coded output is still in the hardware pipeline.
                slots[q.buffer.index].reset();
            }
            for (;;) {
                QueueBuffer q(CAPTURE);
                if (call(fd, VIDIOC_DQBUF, &q.buffer) < 0) {
                    check(errno == EAGAIN, "encoder DQBUF CAPTURE failed",
                          VA_STATUS_ERROR_ENCODING_ERROR);
                    break;
                }
                check(q.buffer.index < capture.size() && !(q.buffer.flags & V4L2_BUF_FLAG_ERROR),
                      "encoder CAPTURE error", VA_STATUS_ERROR_ENCODING_ERROR);
                const auto &memory = capture[q.buffer.index];
                check(q.plane.data_offset <= q.plane.bytesused && q.plane.bytesused <= memory->size,
                      "invalid encoder bitstream range", VA_STATUS_ERROR_ENCODING_ERROR);
                unsigned size = q.plane.bytesused - q.plane.data_offset;
                const uint8_t *data = memory->map() + q.plane.data_offset;
                // A buffer of only parameter sets (Linlon codec-config output)
                // belongs to the next picture, whatever its timestamp; never
                // match it against a job.
                const auto nal = scan_prefix(data, size, settings.hevc);
                if (size && nal.parameters && !nal.slice) {
                    pending_header.insert(pending_header.end(), data, data + size);
                    cached_header = pending_header;
                    trace("encoder parameter sets bytes=%u", size);
                } else if (size) {
                    uint64_t token =
                        uint64_t(q.buffer.timestamp.tv_sec) * 1000000 + q.buffer.timestamp.tv_usec;
                    auto it = jobs.find(token);
                    check(it != jobs.end() && !it->second->frame_done, "encoder timestamp mismatch",
                          VA_STATUS_ERROR_ENCODING_ERROR);
                    auto &job = *it->second;
                    deliver(*job.output, data, size, nal);
                    job.frame_done = true;
                }
                queue_capture(q.buffer.index);
            }
            for (auto it = jobs.begin(); it != jobs.end();) {
                auto &job = *it->second;
                if (job.input_done && job.frame_done) {
                    job.output->coded_ready = true;
                    job.task->pending = false;
                    trace("encoded token=%llu bytes=%u", (unsigned long long)it->first,
                          job.output->coded.size);
                    it = jobs.erase(it);
                } else {
                    ++it;
                }
            }
        } catch (const Error &error) {
            stop(error.status);
            throw;
        } catch (...) {
            stop(VA_STATUS_ERROR_ENCODING_ERROR);
            throw;
        }
    }
    bool wait(const std::shared_ptr<EncodeTask> &task, uint64_t timeout) {
        const auto start = std::chrono::steady_clock::now();
        // Bound active waits, not time since submission: an idle client can
        // leave CAPTURE full until its next VA call requeues those buffers.
        // Also avoid overflowing time_point for VA_TIMEOUT_INFINITE.
        const auto end = start + std::chrono::nanoseconds(std::min<uint64_t>(timeout, 5000000000));
        while (task->pending) {
            refresh();
            if (!task->pending)
                break;
            const auto now = std::chrono::steady_clock::now();
            if (now >= end) {
                if (timeout <= 5000000000)
                    return false; // Caller timeout does not cancel or poison work.
                stop(VA_STATUS_ERROR_ENCODING_ERROR);
                throw Error(VA_STATUS_ERROR_ENCODING_ERROR, "encoder timed out");
            }
            bool input_pending = false;
            for (const auto &[token, job] : jobs)
                input_pending |= !job->input_done;
            auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(end - now);
            pollfd p{fd, short(POLLIN | (input_pending ? POLLOUT : 0)), 0};
            int ret = poll(&p, 1, std::min<int64_t>(100, remaining.count() + 1));
            if ((ret < 0 && errno != EINTR) ||
                (ret > 0 && (p.revents & (POLLERR | POLLHUP | POLLNVAL)))) {
                stop(VA_STATUS_ERROR_ENCODING_ERROR);
                throw Error(VA_STATUS_ERROR_ENCODING_ERROR, "encoder poll failed");
            }
        }
        check(task->status == VA_STATUS_SUCCESS, "asynchronous encoding failed", task->status);
        return true;
    }
    void finish() {
        while (!jobs.empty()) {
            auto task = jobs.begin()->second->task;
            check(wait(task, VA_TIMEOUT_INFINITE), "encoder timed out",
                  VA_STATUS_ERROR_ENCODING_ERROR);
        }
    }
};

Encoder::Encoder(const std::string &device, unsigned width, unsigned height, VAProfile profile,
                 const EncodeSettings &s, const EncodePicture &p, int render_fd) {
    // VA contexts may use macroblock-aligned dimensions (FFmpeg does this).
    // The sequence crop determines the visible dimensions sent to Iris.
    if (!s.hevc) {
        const auto &seq = s.sequence;
        unsigned coded_width = unsigned(seq.picture_width_in_mbs) * 16;
        unsigned coded_height = unsigned(seq.picture_height_in_mbs) * 16;
        check(s.has_sequence && coded_width >= width && coded_width - width < 16 &&
                  coded_height >= height && coded_height - height < 16 &&
                  uint64_t(seq.frame_crop_right_offset) * 2 < coded_width &&
                  uint64_t(seq.frame_crop_bottom_offset) * 2 < coded_height,
              "invalid encoder sequence dimensions", VA_STATUS_ERROR_INVALID_PARAMETER);
        if (seq.frame_cropping_flag) {
            coded_width -= seq.frame_crop_right_offset * 2;
            coded_height -= seq.frame_crop_bottom_offset * 2;
        }
        check(coded_width <= width && coded_height <= height && coded_width >= 128 &&
                  coded_height >= 128,
              "encode crop exceeds context", VA_STATUS_ERROR_INVALID_PARAMETER);
        width = coded_width;
        height = coded_height;
    }
    check(width >= 128 && height >= 128 && width <= 3840 && height <= 2160 && !(width & 1) &&
              !(height & 1),
          "unsupported visible encoder dimensions", VA_STATUS_ERROR_RESOLUTION_NOT_SUPPORTED);
    validate(s, p, width, height);
    auto impl = std::make_unique<Impl>(
        width, height, s, s.hevc ? 1 : p.params.pic_fields.bits.entropy_coding_mode_flag);
    auto &e = *impl;
    e.filter = deblocking(p, s.hevc);
    e.render_fd = fcntl(render_fd, F_DUPFD_CLOEXEC, 0);
    check(e.render_fd >= 0, "duplicate encoder DRM fd");
    // Zero-copy DMABUF input needs coherent MSM GEM (Qualcomm). Elsewhere,
    // including Panthor on CIX Sky1, raw frames are copied into MMAP input.
    int coherent = 0;
    int probe = irisva_msm_allocate(e.render_fd, 4096, &coherent);
    if (probe >= 0)
        close(probe);
    e.fd = open(device.c_str(), O_RDWR | O_NONBLOCK | O_CLOEXEC);
    check(e.fd >= 0, "open V4L2 encoder");
    e.driver = codec_driver(e.fd);
    e.import = probe >= 0 && coherent && e.driver != CodecDriver::Mvx;
    v4l2_format fmt{};
    fmt.type = CAPTURE;
    fmt.fmt.pix_mp.width = width;
    fmt.fmt.pix_mp.height = height;
    fmt.fmt.pix_mp.pixelformat = s.hevc ? V4L2_PIX_FMT_HEVC : V4L2_PIX_FMT_H264;
    checked(e.fd, VIDIOC_S_FMT, &fmt, "encoder S_FMT coded format");
    check(fmt.fmt.pix_mp.pixelformat == (s.hevc ? V4L2_PIX_FMT_HEVC : V4L2_PIX_FMT_H264),
          "encoder does not support the requested encode format",
          VA_STATUS_ERROR_UNSUPPORTED_PROFILE);
    fmt = {};
    fmt.type = OUTPUT;
    fmt.fmt.pix_mp.width = width;
    fmt.fmt.pix_mp.height = height;
    fmt.fmt.pix_mp.pixelformat = V4L2_PIX_FMT_NV12;
    fmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
    checked(e.fd, VIDIOC_S_FMT, &fmt, "encoder S_FMT NV12");
    {
        const auto &input = fmt.fmt.pix_mp;
        // Linlon describes NV12 as two discrete planes sharing one pitch.
        check(input.pixelformat == V4L2_PIX_FMT_NV12 &&
                  (input.num_planes == 1 ||
                   (input.num_planes == 2 && !e.import &&
                    input.plane_fmt[1].bytesperline == input.plane_fmt[0].bytesperline)),
              "unsupported encoder input layout");
        e.input_planes = input.num_planes;
        for (unsigned i = 0; i < e.input_planes; ++i)
            e.plane_sizes[i] = input.plane_fmt[i].sizeimage;
    }
    e.stride = fmt.fmt.pix_mp.plane_fmt[0].bytesperline;
    e.storage_height = fmt.fmt.pix_mp.height;
    e.input_size = fmt.fmt.pix_mp.plane_fmt[0].sizeimage;
    v4l2_selection crop{};
    crop.type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
    crop.target = V4L2_SEL_TGT_CROP;
    crop.r.width = width;
    crop.r.height = height;
    checked(e.fd, VIDIOC_S_SELECTION, &crop, "encoder S_SELECTION");
    if (s.hevc) {
        e.control(V4L2_CID_MPEG_VIDEO_HEVC_PROFILE, V4L2_MPEG_VIDEO_HEVC_PROFILE_MAIN);
        e.control(V4L2_CID_MPEG_VIDEO_HEVC_LEVEL,
                  hevc_level_control(s.hevc_sequence.general_level_idc));
        v4l2_queryctrl tier{};
        tier.id = V4L2_CID_MPEG_VIDEO_HEVC_TIER;
        int ret = call(e.fd, VIDIOC_QUERYCTRL, &tier);
        check(ret == 0 || errno == EINVAL, "query HEVC tier control",
              VA_STATUS_ERROR_ENCODING_ERROR);
        if (ret == 0 && !(tier.flags & V4L2_CTRL_FLAG_DISABLED))
            e.control(tier.id, s.hevc_sequence.general_tier_flag);
        else
            check(!s.hevc_sequence.general_tier_flag, "HEVC High tier requires a tier control",
                  VA_STATUS_ERROR_UNIMPLEMENTED);
    } else {
        e.control(V4L2_CID_MPEG_VIDEO_H264_PROFILE,
                  profile == VAProfileH264High ? V4L2_MPEG_VIDEO_H264_PROFILE_HIGH
                  : profile == VAProfileH264Main
                      ? V4L2_MPEG_VIDEO_H264_PROFILE_MAIN
                      : V4L2_MPEG_VIDEO_H264_PROFILE_CONSTRAINED_BASELINE);
        e.control(V4L2_CID_MPEG_VIDEO_H264_LEVEL, level_control(s.sequence.level_idc));
        e.control(V4L2_CID_MPEG_VIDEO_H264_ENTROPY_MODE, e.entropy);
    }
    e.control(V4L2_CID_MPEG_VIDEO_B_FRAMES, 0);
    // Keyframes follow VA picture requests; prevent autonomous periodic IDRs.
    e.control(V4L2_CID_MPEG_VIDEO_GOP_SIZE, std::numeric_limits<int>::max());
    // Iris joins parameter sets to each IDR. Linlon implements neither control;
    // refresh() then merges its separate parameter-set buffer into the first
    // picture and repeats the cached sets before every later keyframe.
    e.optional_control(V4L2_CID_MPEG_VIDEO_HEADER_MODE,
                       V4L2_MPEG_VIDEO_HEADER_MODE_JOINED_WITH_1ST_FRAME);
    e.emulate_prepend = !e.optional_control(V4L2_CID_MPEG_VIDEO_PREPEND_SPSPPS_TO_IDR, 1);
    if (e.driver == CodecDriver::Mvx) {
        // Annex B start codes ("Start codes" is menu index 1).
        if (uint32_t nalu = find_control(e.fd, "nalu format"))
            e.control(nalu, 1);
    }
    e.control(V4L2_CID_MPEG_VIDEO_FRAME_RC_ENABLE, s.rate_control != VA_RC_CQP);
    if (s.rate_control != VA_RC_CQP) {
        e.control(V4L2_CID_MPEG_VIDEO_BITRATE_MODE, s.rate_control == VA_RC_CBR
                                                        ? V4L2_MPEG_VIDEO_BITRATE_MODE_CBR
                                                        : V4L2_MPEG_VIDEO_BITRATE_MODE_VBR);
        e.control(V4L2_CID_MPEG_VIDEO_BITRATE, s.bitrate);
        e.control(V4L2_CID_MPEG_VIDEO_BITRATE_PEAK, s.peak_bitrate);
    }
    e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_MIN_QP : V4L2_CID_MPEG_VIDEO_H264_MIN_QP, s.min_qp);
    e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_MAX_QP : V4L2_CID_MPEG_VIDEO_H264_MAX_QP, s.max_qp);
    e.configure_deblocking();
    if (s.rate_control == VA_RC_CQP) {
        // Configure the first picture's QP before the firmware starts: some
        // drivers (Linlon) load the session at STREAMON with QP 0 otherwise.
        int qp = s.hevc ? int(p.hevc_params.pic_init_qp) + p.hevc_slices.front().slice_qp_delta
                        : int(p.params.pic_init_qp) + p.slices.front().slice_qp_delta;
        if (qp >= 1 && qp <= 51) {
            e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_I_FRAME_QP
                             : V4L2_CID_MPEG_VIDEO_H264_I_FRAME_QP,
                      qp);
            e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_P_FRAME_QP
                             : V4L2_CID_MPEG_VIDEO_H264_P_FRAME_QP,
                      qp);
            e.current_qp = qp;
        }
    }
    // OUTPUT first: Linlon takes the rate from OUTPUT and only validates CAPTURE.
    for (unsigned type : {OUTPUT, CAPTURE}) {
        v4l2_streamparm parm{};
        parm.type = type;
        parm.parm.output.timeperframe.numerator = s.fps_den;
        parm.parm.output.timeperframe.denominator = s.fps_num;
        checked(e.fd, VIDIOC_S_PARM, &parm, "encoder S_PARM");
    }
    // Iris sizes coded buffers differently when rate control is disabled.
    // Refresh CAPTURE after controls, before allocating either queue.
    fmt = {};
    fmt.type = CAPTURE;
    fmt.fmt.pix_mp.width = width;
    fmt.fmt.pix_mp.height = height;
    fmt.fmt.pix_mp.pixelformat = s.hevc ? V4L2_PIX_FMT_HEVC : V4L2_PIX_FMT_H264;
    checked(e.fd, VIDIOC_S_FMT, &fmt, "encoder refresh CAPTURE format");
    unsigned input_buffers = 4;
    {
        v4l2_control minimum{};
        minimum.id = V4L2_CID_MIN_BUFFERS_FOR_OUTPUT;
        if (call(e.fd, VIDIOC_G_CTRL, &minimum) == 0 && minimum.value > 0)
            input_buffers = std::min(16u, std::max(input_buffers, unsigned(minimum.value)));
    }
    for (unsigned type : {OUTPUT, CAPTURE}) {
        v4l2_requestbuffers req{};
        req.type = type;
        req.memory = type == OUTPUT && e.import ? V4L2_MEMORY_DMABUF : V4L2_MEMORY_MMAP;
        req.count = type == OUTPUT ? input_buffers : 4;
        checked(e.fd, VIDIOC_REQBUFS, &req, "encoder REQBUFS");
        check(req.count && req.count <= 64, "invalid encoder buffer count");
        if (type == OUTPUT) {
            e.input_count = req.count;
            if (e.import)
                continue;
        }
        for (unsigned i = 0; i < req.count; ++i) {
            const unsigned planes = type == OUTPUT ? e.input_planes : 1;
            QueueBuffer q(type, i, false, planes);
            checked(e.fd, VIDIOC_QUERYBUF, &q.buffer, "encoder QUERYBUF");
            check(q.buffer.length == planes, "unexpected encoder buffer plane count");
            auto m = std::make_shared<Memory>();
            m->origin = MemoryOrigin::Iris;
            m->index = i;
            m->size = q.plane.length;
            if (planes == 1) {
                void *ptr = mmap(nullptr, m->size, PROT_READ | PROT_WRITE, MAP_SHARED, e.fd,
                                 q.plane.m.mem_offset);
                check(ptr != MAP_FAILED, "mmap encoder buffer");
                m->mapping = ptr;
            }
            if (type == OUTPUT) {
                m->stride = e.stride;
                m->storage_height = e.storage_height;
                m->width = e.width;
                m->height = e.height;
                // Split input is mapped through its exported DMA-BUFs.
                for (unsigned p = 0; p < planes; ++p) {
                    v4l2_exportbuffer exp{};
                    exp.type = OUTPUT;
                    exp.index = i;
                    exp.plane = p;
                    exp.flags = O_CLOEXEC | O_RDWR;
                    checked(e.fd, VIDIOC_EXPBUF, &exp, "encoder EXPBUF OUTPUT");
                    if (p) {
                        m->chroma_fd = exp.fd;
                        m->chroma_size = q.planes[p].length;
                    } else {
                        m->fd = exp.fd;
                    }
                }
                e.raw.push_back(m);
            } else {
                e.capture.push_back(m);
                e.queue_capture(i);
            }
        }
    }
    e.slots.resize(e.input_count);
    e.staging.resize(e.input_count);
    unsigned type = OUTPUT;
    checked(e.fd, VIDIOC_STREAMON, &type, "encoder STREAMON OUTPUT");
    e.output_on = true;
    type = CAPTURE;
    checked(e.fd, VIDIOC_STREAMON, &type, "encoder STREAMON CAPTURE");
    e.capture_on = true;
    trace("encoder %s %ux%u stride=%u storage-height=%u size=%u planes=%u RC=%u queue=%s "
          "prepend=%s",
          device.c_str(), width, height, e.stride, e.storage_height, e.input_size, e.input_planes,
          s.rate_control, e.import ? "dmabuf" : "mmap", e.emulate_prepend ? "emulated" : "driver");
    impl_ = std::move(impl);
}
Encoder::~Encoder() = default;

std::shared_ptr<EncodeTask> Encoder::encode(const EncodeSettings &s, const EncodePicture &p,
                                            const std::shared_ptr<Surface> &input,
                                            const std::shared_ptr<Buffer> &coded) {
    auto &output = *coded;
    auto &e = *impl_;
    check(!e.failed, "encoder session failed; create a new context",
          VA_STATUS_ERROR_ENCODING_ERROR);
    validate(s, p, e.width, e.height);
    check(deblocking(p, s.hevc) == e.filter, "changing deblocking requires a new context",
          VA_STATUS_ERROR_UNIMPLEMENTED);
    check((s.hevc
               ? s.hevc_sequence.general_level_idc == e.settings.hevc_sequence.general_level_idc &&
                     s.hevc_sequence.general_tier_flag == e.settings.hevc_sequence.general_tier_flag
               : s.sequence.level_idc == e.settings.sequence.level_idc &&
                     p.params.pic_fields.bits.entropy_coding_mode_flag == e.entropy) &&
              s.fps_num == e.settings.fps_num && s.fps_den == e.settings.fps_den &&
              s.bitrate == e.settings.bitrate && s.peak_bitrate == e.settings.peak_bitrate &&
              s.min_qp == e.settings.min_qp && s.max_qp == e.settings.max_qp,
          "changing encoder settings requires a new context", VA_STATUS_ERROR_UNIMPLEMENTED);
    const bool idr =
        s.hevc ? p.hevc_params.pic_fields.bits.idr_pic_flag : p.params.pic_fields.bits.idr_pic_flag;
    const bool intra =
        s.hevc ? p.hevc_slices.front().slice_type == 2 : p.slices.front().slice_type % 5 == 2;
    check(e.token || idr, "encoder must start with IDR", VA_STATUS_ERROR_INVALID_PARAMETER);
    // Clients with multiple GOPs per IDR (including Sunshine) submit non-IDR
    // I pictures / HEVC CRA. Iris only exposes FORCE_KEY_FRAME, which emits IDR.
    // Promote these requests to IDR and drain before changing the control below.
    // This is safe with our I/P-only, immediately preceding reference contract:
    // no later picture can refer across this reset. Firmware owns headers/POC;
    // never relabel an inter-coded picture or rewrite the firmware's NAL header.
    if (!intra) {
        VASurfaceID reference;
        bool valid;
        if (s.hevc) {
            const auto &ref = p.hevc_slices.front().ref_pic_list0[0];
            reference = ref.picture_id;
            valid = !(ref.flags & (VA_PICTURE_HEVC_INVALID | VA_PICTURE_HEVC_LONG_TERM_REFERENCE));
        } else {
            const auto &ref = p.slices.front().RefPicList0[0];
            reference = ref.picture_id;
            valid = !(ref.flags & (VA_PICTURE_H264_INVALID | VA_PICTURE_H264_LONG_TERM_REFERENCE));
        }
        check(valid && reference == e.last_reference && e.last_reference != VA_INVALID_SURFACE,
              "encoder only supports the immediately preceding reference",
              VA_STATUS_ERROR_UNIMPLEMENTED);
    }
    check(s.hevc ? p.hevc_params.pic_fields.bits.reference_pic_flag
                 : p.params.pic_fields.bits.reference_pic_flag,
          "non-reference encoding unsupported", VA_STATUS_ERROR_UNIMPLEMENTED);
    auto memory = input->memory;
    check(memory && memory->fourcc == VA_FOURCC_NV12 && memory->width >= e.width &&
              memory->height >= e.height,
          "invalid encoder input surface", VA_STATUS_ERROR_INVALID_SURFACE);
    check(!output.coded_mapped, "coded buffer is mapped", VA_STATUS_ERROR_SURFACE_BUSY);
    int qp = s.hevc ? int(p.hevc_params.pic_init_qp) + p.hevc_slices.front().slice_qp_delta
                    : int(p.params.pic_init_qp) + p.slices.front().slice_qp_delta;
    check(qp >= 1 && qp <= 51, "invalid encode picture QP", VA_STATUS_ERROR_INVALID_PARAMETER);
    e.refresh();
    check(!output.encode_task || !output.encode_task->pending, "coded buffer is pending",
          VA_STATUS_ERROR_SURFACE_BUSY);
    try {
        // Scalar V4L2 controls have no per-request association. Drain before a
        // QP change or forced IDR so they cannot affect an earlier queued frame.
        // Linlon flags a forced IDR on the input buffer itself, so only Iris
        // (FORCE_KEY_FRAME control) needs a drain for keyframe requests.
        const bool keyframe_control = e.driver != CodecDriver::Mvx;
        if ((s.rate_control == VA_RC_CQP && qp != e.current_qp) ||
            (intra && e.token && keyframe_control))
            e.finish();
        if (e.jobs.size() == e.input_count + e.capture.size()) {
            auto task = e.jobs.begin()->second->task;
            check(e.wait(task, VA_TIMEOUT_INFINITE), "encoder timed out",
                  VA_STATUS_ERROR_ENCODING_ERROR);
        }
        unsigned index;
        const auto slot_deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
        for (;;) {
            for (index = 0; index < e.slots.size() && e.slots[index]; ++index) {
            }
            if (index < e.slots.size())
                break;
            check(std::chrono::steady_clock::now() < slot_deadline, "encoder input queue timed out",
                  VA_STATUS_ERROR_ENCODING_ERROR);
            pollfd ready{e.fd, short(POLLIN | POLLOUT), 0};
            int ret = poll(&ready, 1, 100);
            check((ret >= 0 || errno == EINTR) && !(ready.revents & (POLLERR | POLLHUP | POLLNVAL)),
                  "encoder input queue poll failed", VA_STATUS_ERROR_ENCODING_ERROR);
            e.refresh();
        }
        const bool direct =
            e.import && memory->fd >= 0 &&
            (memory->origin == MemoryOrigin::MsmCoherent || memory->origin == MemoryOrigin::Iris ||
             memory->origin == MemoryOrigin::DmaHeap) &&
            memory->stride == e.stride && memory->storage_height == e.storage_height &&
            !memory->data_offset && memory->size >= e.input_size;
        if (!e.import) {
            auto raw = e.raw[index];
            copy_surface(*raw, *memory, e.width, e.height);
            memory = raw;
        } else if (!direct) {
            // Never send write-combined GEM directly to a coherent VPU, or
            // GPU-write an Iris MMAP allocation with cached CPU aliases.
            if (!e.staging[index]) {
                auto m = std::make_shared<Memory>();
                m->width = e.width;
                m->height = e.height;
                m->stride = e.stride;
                m->storage_height = e.storage_height;
                m->size = e.input_size;
                int coherent = 0;
                m->fd = irisva_msm_allocate(e.render_fd, m->size, &coherent);
                check(m->fd >= 0 && coherent, "allocate coherent encoder staging",
                      VA_STATUS_ERROR_ALLOCATION_FAILED);
                m->origin = MemoryOrigin::MsmCoherent;
                e.staging[index] = m;
                if (!e.copier)
                    e.copier = std::make_unique<SurfaceCopier>(e.render_fd);
            }
            e.copier->copy(e.staging[index], memory, e.width, e.height);
            memory = e.staging[index];
        }
        // Retain the input through both DQBUFs, and STREAMOFF before releasing
        // it if a job fails. Cache coherency does not replace lifetime/fences.
        wait_surface_access(*memory, POLLIN);
        trace("encoder input path=%s origin=%u",
              direct     ? "direct"
              : e.import ? "staging"
                         : "cpu-mmap",
              unsigned(memory->origin));
        if (s.rate_control == VA_RC_CQP && qp != e.current_qp) {
            e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_I_FRAME_QP
                             : V4L2_CID_MPEG_VIDEO_H264_I_FRAME_QP,
                      qp);
            e.control(s.hevc ? V4L2_CID_MPEG_VIDEO_HEVC_P_FRAME_QP
                             : V4L2_CID_MPEG_VIDEO_H264_P_FRAME_QP,
                      qp);
            e.current_qp = qp;
        }
        if (intra && e.token && keyframe_control)
            e.control(V4L2_CID_MPEG_VIDEO_FORCE_KEY_FRAME, 0);
        QueueBuffer q(OUTPUT, index, e.import, e.input_planes);
        if (e.import)
            q.plane.m.fd = memory->fd;
        if (e.input_planes == 1) {
            q.plane.length = memory->size;
            q.plane.bytesused = e.input_size;
        } else {
            for (unsigned p = 0; p < e.input_planes; ++p) {
                q.planes[p].length = p ? memory->chroma_size : memory->size;
                q.planes[p].bytesused = e.plane_sizes[p];
            }
        }
        // Linlon: KEYFRAME on a raw input buffer requests an IDR for it.
        if (intra && e.token && !keyframe_control)
            q.buffer.flags |= V4L2_BUF_FLAG_KEYFRAME;
        const uint64_t token = e.token + 1;
        q.buffer.timestamp.tv_sec = token / 1000000;
        q.buffer.timestamp.tv_usec = token % 1000000;
        auto job = std::make_shared<Impl::Job>();
        job->task = std::make_shared<EncodeTask>();
        job->output = coded;
        job->memory = memory;
        e.jobs.emplace(token, job);
        e.slots[index] = job;
        output.encode_task = job->task;
        output.coded_ready = false;
        output.coded = {};
        checked(e.fd, VIDIOC_QBUF, &q.buffer, "encoder QBUF OUTPUT");
        e.token = token;
        e.last_reference = p.reconstruction(s.hevc);
        trace("encoder queued token=%llu depth=%zu", (unsigned long long)token, e.jobs.size());
        return job->task;
    } catch (const Error &error) {
        e.stop(error.status);
        throw;
    } catch (...) {
        e.stop(VA_STATUS_ERROR_ENCODING_ERROR);
        throw;
    }
}
bool Encoder::sync(const std::shared_ptr<EncodeTask> &task, uint64_t timeout) {
    return impl_->wait(task, timeout);
}
void Encoder::refresh() {
    impl_->refresh();
}
void Encoder::finish() {
    impl_->finish();
}
} // namespace irisva
